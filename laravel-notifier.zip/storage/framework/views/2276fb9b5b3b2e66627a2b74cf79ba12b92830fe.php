<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="container">
  			<div class="main-section">
		      	<h1>Create a Deal Alert</h1>
		      	<div class="row model-list">
			      	<div class="col-md-6">
			          	<div class="clearfix">
			         		<img src="<?php echo e(asset('images/model-s.png')); ?>">
			         		<a href="<?php echo e(URL::to('/alert/1')); ?>"><h2>Model S</h2></a>
			          	</div>
			        </div>
			        <div class="col-md-6">
			          	<div class="clearfix">
			         		<img src="<?php echo e(asset('images/model-x.png')); ?>">
			         		<a href="<?php echo e(URL::to('/alert/2')); ?>"><h2>Model x</h2></a>
			          	</div>
		        	</div>	
		      	</div>
		       	
     		</div>
    	</div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
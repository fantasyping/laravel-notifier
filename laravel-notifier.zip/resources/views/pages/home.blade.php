@extends('layouts.default')

@section('content')
<div class="container main-content">
    <!-- <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in!
                </div>
            </div>
        </div>
    </div> -->
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel-body">
                <a href="{{ URL::to('/alert/new') }}" class="btn btn-sq-lg content-btns">
                    <img src="{{asset('images/deal-alert.png')}}" class="first-img"><br/><br/>
                    Create a Deal Alert
                </a>
                <a href="#" class="btn btn-sq-lg content-btns">
                    <img src="{{asset('images/ic_notifications.png')}}" class="first-img"><br/><br/>
                    Manage Alert
                  
                </a>
                <a href="#" class="btn btn-sq-lg content-btns">
                    <img src="{{asset('images/account_box.png')}}" class="first-img"><br/><br/>
                    Account Details
                </a>
            </div>
                
        </div>
    </div>
</div>
@endsection



<div class="navbar navbar-fixed-bottom navbar-default footer">

	<div class="container footer-navbar">
	        <strong>Copyright &copy; 2017 <a href="/">teslaalerts.com</a>.</strong> All rights
	        reserved.

	        <div class="pull-right">
	            <a href="/privacy">Site Privacy Policy</a> | <a href="/terms">Terms of Use</a> | <a href="/contact">Contact Us</a>
	        </div>

	</div>

</div>
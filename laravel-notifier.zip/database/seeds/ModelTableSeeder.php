<?php

use Illuminate\Database\Seeder;

class ModelTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::create([
            'model_name' => 'Model S',
            'user_id' => '2',
        ]);
        Model::create([
            'model_name' => 'Model X',
            'user_id' => '2',
        ]);
    }
}

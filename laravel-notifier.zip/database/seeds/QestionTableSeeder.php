<?php

use Illuminate\Database\Seeder;

class QestionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Question::create([
            'question_name' => 'Desired Trim(s)',
            'user_id' => '2',
            'alert_id' => '1',
        ]);
        Question::create([
            'question_name' => 'Required Packages',
            'user_id' => '2',
            'alert_id' => '1',
        ]);
        Question::create([
            'question_name' => 'Desired Colors',
            'user_id' => '2',
            'alert_id' => '1',
        ]);
        Question::create([
            'question_name' => 'Required Price',
            'user_id' => '2',
            'alert_id' => '1',
        ]);
        Question::create([
            'question_name' => 'Desired Seats',
            'user_id' => '2',
            'alert_id' => '1',
        ]);

        Question::create([
            'question_name' => 'Desired Trim(s)',
            'user_id' => '2',
            'alert_id' => '2',
        ]);
        Question::create([
            'question_name' => 'Required Packages',
            'user_id' => '2',
            'alert_id' => '2',
        ]);
        Question::create([
            'question_name' => 'Desired Seats',
            'user_id' => '2',
            'alert_id' => '2',
        ]);
        Question::create([
            'question_name' => 'Desired Color(s)',
            'user_id' => '2',
            'alert_id' => '2',
        ]);
        Question::create([
            'question_name' => 'Required Price',
            'user_id' => '2',
            'alert_id' => '2',
        ]);

    }
}

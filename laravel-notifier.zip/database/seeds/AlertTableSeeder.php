<?php

use Illuminate\Database\Seeder;

class AlertTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Alert::create([
            'alert_name' => 'Please Create Alert For Model S',
            'alert_time' => '4',
            'questions_count' => '4',
            'time_per_question' => '1',
            'editor_id' => '2',
            'model_id' => '2',
        ]);

        Alert::create([
            'alert_name' => 'Please Create Alert For Model X',
            'alert_time' => '5',
            'questions_count' => '5',
            'time_per_question' => '1',
            'editor_id' => '2',
            'model_id' => '1',
        ]);

    }
}
